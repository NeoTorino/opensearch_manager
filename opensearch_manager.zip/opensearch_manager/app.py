from __future__ import annotations

import json
import os
import secrets
import uuid
from datetime import datetime
from pathlib import Path
from math import ceil
from typing import Any

from flask import (
    Flask, abort, flash, redirect, render_template, request, url_for
)
from flask_wtf.csrf import CSRFProtect
from opensearchpy import OpenSearch, exceptions as os_exceptions


BASE_DIR = Path(__file__).resolve().parent
INSTANCE_DIR = BASE_DIR / "instance"
CONFIG_FILE = INSTANCE_DIR / "config.json"
MAPPINGS_DIR = BASE_DIR / "mappings"

INSTANCE_DIR.mkdir(mode=0o700, parents=True, exist_ok=True)

DEFAULT_CONFIG = {
    "host": "192.168.2.250",
    "port": 9200,
    "username": "admin",
    "password": "",
    "ca_certs": "",
    "use_ssl": True,
    "verify_certs": True,
    "timeout": 15,
    "secret_key": secrets.token_urlsafe(48),
}

INDEXES = {
    "orgs": {
        "title": "Organisations",
        "mapping_file": "orgs_mapping.json",
        "columns": [
            "name", "country", "country_code", "active",
            "jobs_posted", "url", "updated_at",
        ],
    },
    "jobs": {
        "title": "Jobs",
        "mapping_file": "jobs_mapping.json",
        "columns": [
            "title", "org_id", "country", "country_code",
            "date_posted", "active", "salary_min", "salary_max",
            "currency",
        ],
    },
}

# These keyword fields are presented as one-value-per-line text areas.
# Edit this set if your data uses a different multi-value convention.
MULTI_VALUE_FIELDS = {"tags", "skills", "language"}

TEXTAREA_FIELDS = {
    "description", "summary", "address", "location",
    "location_2", "location_3",
}


def save_config(config: dict[str, Any]) -> None:
    INSTANCE_DIR.mkdir(mode=0o700, parents=True, exist_ok=True)
    temporary = CONFIG_FILE.with_suffix(".tmp")
    temporary.write_text(json.dumps(config, indent=2), encoding="utf-8")
    os.replace(temporary, CONFIG_FILE)
    try:
        os.chmod(CONFIG_FILE, 0o600)
        os.chmod(INSTANCE_DIR, 0o700)
    except OSError:
        # Windows does not implement POSIX file permissions.
        pass


def load_config() -> dict[str, Any]:
    if not CONFIG_FILE.exists():
        config = DEFAULT_CONFIG.copy()
        save_config(config)
        return config

    try:
        stored = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
        config = DEFAULT_CONFIG.copy()
        config.update(stored)
        return config
    except (OSError, json.JSONDecodeError):
        # Keep the application startable if the settings file is damaged.
        return DEFAULT_CONFIG.copy()


def load_mapping(index_name: str) -> dict[str, Any]:
    if index_name not in INDEXES:
        abort(404)
    path = MAPPINGS_DIR / INDEXES[index_name]["mapping_file"]
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return data["mappings"]["properties"]
    except (OSError, json.JSONDecodeError, KeyError) as exc:
        raise RuntimeError(f"Could not load mapping for {index_name}: {exc}") from exc


def create_client(config: dict[str, Any] | None = None) -> OpenSearch:
    cfg = config or load_config()
    host = str(cfg.get("host", "")).strip()
    if not host:
        raise ValueError("OpenSearch host/IP has not been configured.")

    try:
        port = int(cfg.get("port", 9200))
        timeout = int(cfg.get("timeout", 15))
    except (TypeError, ValueError) as exc:
        raise ValueError("Port and timeout must be numbers.") from exc

    if not 1 <= port <= 65535:
        raise ValueError("Port must be between 1 and 65535.")

    use_ssl = bool(cfg.get("use_ssl", True))
    verify_certs = bool(cfg.get("verify_certs", True)) if use_ssl else False
    ca_certs = str(cfg.get("ca_certs", "")).strip()

    if ca_certs:
        cert_path = Path(ca_certs).expanduser()
        if not cert_path.is_absolute():
            cert_path = BASE_DIR / cert_path
        if not cert_path.exists():
            raise ValueError(f"CA certificate path does not exist: {cert_path}")
        ca_certs = str(cert_path)
    else:
        ca_certs = None

    username = str(cfg.get("username", "")).strip()
    password = str(cfg.get("password", ""))
    http_auth = (username, password) if username else None

    return OpenSearch(
        hosts=[{"host": host, "port": port}],
        http_auth=http_auth,
        use_ssl=use_ssl,
        verify_certs=verify_certs,
        ca_certs=ca_certs,
        ssl_assert_hostname=verify_certs,
        ssl_show_warn=verify_certs,
        http_compress=True,
        timeout=timeout,
        max_retries=2,
        retry_on_timeout=True,
    )


def format_value(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, bool):
        return "Yes" if value else "No"
    if isinstance(value, list):
        return ", ".join(str(item) for item in value)
    if isinstance(value, dict):
        return json.dumps(value, ensure_ascii=False)
    return str(value)


def parse_field_value(field_name: str, field_mapping: dict[str, Any], raw: str) -> Any:
    field_type = field_mapping.get("type")

    if field_name in MULTI_VALUE_FIELDS:
        values = [item.strip() for item in raw.splitlines() if item.strip()]
        return values if values else None

    if raw == "":
        return None

    if field_type == "boolean":
        lowered = raw.lower()
        if lowered == "true":
            return True
        if lowered == "false":
            return False
        raise ValueError(f"{field_name}: choose Yes or No.")

    if field_type == "integer":
        try:
            return int(raw)
        except ValueError as exc:
            raise ValueError(f"{field_name}: enter a whole number.") from exc

    if field_type in {"float", "double", "long", "short", "byte"}:
        try:
            return float(raw) if field_type in {"float", "double"} else int(raw)
        except ValueError as exc:
            raise ValueError(f"{field_name}: enter a valid number.") from exc

    if field_type == "date":
        # OpenSearch accepts ISO date and date-time values.
        try:
            datetime.fromisoformat(raw.replace("Z", "+00:00"))
        except ValueError as exc:
            raise ValueError(
                f"{field_name}: use YYYY-MM-DD or an ISO-8601 date/time."
            ) from exc
        return raw

    return raw


def build_document(index_name: str, form, is_new: bool) -> dict[str, Any]:
    properties = load_mapping(index_name)
    document: dict[str, Any] = {}

    for field_name, field_mapping in properties.items():
        raw = form.get(field_name, "")
        value = parse_field_value(field_name, field_mapping, raw)

        if is_new and (raw == "" or (field_name in MULTI_VALUE_FIELDS and value is None)):
            continue

        # On edits, blank fields are stored as null, clearing their old values.
        if value is not None or not is_new:
            document[field_name] = value

    return document


def search_documents(index_name: str, query: str, page: int, page_size: int = 25):
    client = create_client()
    properties = load_mapping(index_name)

    if query.strip():
        searchable_fields = [
            name for name, spec in properties.items()
            if spec.get("type") in {"text", "keyword"}
            or "fields" in spec
        ]
        search_query = {
            "simple_query_string": {
                "query": query.strip(),
                "fields": searchable_fields,
                "default_operator": "and",
            }
        }
    else:
        search_query = {"match_all": {}}

    response = client.search(
        index=index_name,
        body={
            "from": (page - 1) * page_size,
            "size": page_size,
            "track_total_hits": True,
            "query": search_query,
            "sort": [{"_doc": "asc"}],
        },
    )

    total_info = response["hits"]["total"]
    total = total_info["value"] if isinstance(total_info, dict) else total_info
    pages = max(1, ceil(total / page_size))

    records = []
    for hit in response["hits"]["hits"]:
        source = hit.get("_source", {})
        records.append({
            "id": hit["_id"],
            "source": source,
            "values": [format_value(source.get(col)) for col in INDEXES[index_name]["columns"]],
        })

    return records, total, pages


app = Flask(__name__)
app.config["SECRET_KEY"] = load_config()["secret_key"]
app.config["MAX_CONTENT_LENGTH"] = 2 * 1024 * 1024
CSRFProtect(app)


@app.template_filter("display_value")
def display_value(value):
    return format_value(value)


@app.context_processor
def inject_globals():
    return {"indexes": INDEXES}


def friendly_opensearch_error(exc: Exception) -> str:
    if isinstance(exc, os_exceptions.AuthenticationException):
        return "Authentication failed. Check your OpenSearch username and password in Settings."
    if isinstance(exc, os_exceptions.AuthorizationException):
        return "OpenSearch rejected this operation. Check the user's index permissions."
    if isinstance(exc, os_exceptions.NotFoundError):
        return "The requested document or index was not found."
    return str(exc)


@app.route("/")
def home():
    return redirect(url_for("index_view", index_name="orgs"))


@app.route("/index/<index_name>")
def index_view(index_name: str):
    if index_name not in INDEXES:
        abort(404)

    query = request.args.get("q", "").strip()
    try:
        page = max(1, int(request.args.get("page", "1")))
    except ValueError:
        page = 1

    try:
        records, total, pages = search_documents(index_name, query, page)
        if page > pages:
            return redirect(url_for(
                "index_view", index_name=index_name, q=query, page=pages
            ))
        return render_template(
            "index.html",
            index_name=index_name,
            index_info=INDEXES[index_name],
            columns=INDEXES[index_name]["columns"],
            records=records,
            total=total,
            page=page,
            pages=pages,
            query=query,
        )
    except Exception as exc:
        flash(f"Could not load {index_name}: {friendly_opensearch_error(exc)}", "danger")
        return render_template(
            "index.html",
            index_name=index_name,
            index_info=INDEXES[index_name],
            columns=INDEXES[index_name]["columns"],
            records=[],
            total=0,
            page=1,
            pages=1,
            query=query,
            connection_error=True,
        )


@app.route("/index/<index_name>/new", methods=["GET", "POST"])
def create_document(index_name: str):
    if index_name not in INDEXES:
        abort(404)

    properties = load_mapping(index_name)
    values = {}

    if request.method == "POST":
        try:
            document = build_document(index_name, request.form, is_new=True)
            if not document:
                raise ValueError("Enter at least one field before creating the document.")

            client = create_client()
            document_id = uuid.uuid4().hex
            client.index(
                index=index_name,
                id=document_id,
                body=document,
                refresh="wait_for",
            )
            flash(f"Document created successfully (ID: {document_id}).", "success")
            return redirect(url_for("edit_document", index_name=index_name, doc_id=document_id))
        except Exception as exc:
            flash(f"Could not create document: {friendly_opensearch_error(exc)}", "danger")
            values = request.form.to_dict()

    return render_template(
        "document_form.html",
        index_name=index_name,
        index_info=INDEXES[index_name],
        properties=properties,
        values=values,
        mode="new",
        doc_id=None,
        multi_value_fields=MULTI_VALUE_FIELDS,
        textarea_fields=TEXTAREA_FIELDS,
    )


@app.route("/index/<index_name>/<doc_id>/edit", methods=["GET", "POST"])
def edit_document(index_name: str, doc_id: str):
    if index_name not in INDEXES:
        abort(404)

    properties = load_mapping(index_name)
    client = create_client()

    try:
        response = client.get(index=index_name, id=doc_id)
        current_source = response.get("_source", {})
    except Exception as exc:
        flash(f"Could not retrieve document: {friendly_opensearch_error(exc)}", "danger")
        return redirect(url_for("index_view", index_name=index_name))

    values = current_source.copy()

    if request.method == "POST":
        if request.form.get("action") == "delete":
            return redirect(url_for("delete_document", index_name=index_name, doc_id=doc_id))

        try:
            document = build_document(index_name, request.form, is_new=False)
            client.index(
                index=index_name,
                id=doc_id,
                body=document,
                refresh="wait_for",
            )
            flash("Document updated successfully.", "success")
            return redirect(url_for("edit_document", index_name=index_name, doc_id=doc_id))
        except Exception as exc:
            flash(f"Could not update document: {friendly_opensearch_error(exc)}", "danger")
            values = request.form.to_dict()

    return render_template(
        "document_form.html",
        index_name=index_name,
        index_info=INDEXES[index_name],
        properties=properties,
        values=values,
        mode="edit",
        doc_id=doc_id,
        multi_value_fields=MULTI_VALUE_FIELDS,
        textarea_fields=TEXTAREA_FIELDS,
    )


@app.route("/index/<index_name>/<doc_id>/delete", methods=["POST", "GET"])
def delete_document(index_name: str, doc_id: str):
    if index_name not in INDEXES:
        abort(404)

    if request.method == "GET":
        return render_template(
            "confirm_delete.html",
            index_name=index_name,
            index_info=INDEXES[index_name],
            doc_id=doc_id,
        )

    try:
        client = create_client()
        client.delete(index=index_name, id=doc_id, refresh="wait_for")
        flash(f"Document {doc_id} deleted.", "success")
    except Exception as exc:
        flash(f"Could not delete document: {friendly_opensearch_error(exc)}", "danger")

    return redirect(url_for("index_view", index_name=index_name))


@app.route("/settings", methods=["GET", "POST"])
def settings():
    current = load_config()

    if request.method == "POST":
        candidate = current.copy()
        candidate["host"] = request.form.get("host", "").strip()
        candidate["username"] = request.form.get("username", "").strip()
        candidate["ca_certs"] = request.form.get("ca_certs", "").strip()
        candidate["use_ssl"] = request.form.get("use_ssl") == "on"
        candidate["verify_certs"] = request.form.get("verify_certs") == "on"

        try:
            candidate["port"] = int(request.form.get("port", "9200"))
            candidate["timeout"] = int(request.form.get("timeout", "15"))
            if not candidate["host"]:
                raise ValueError("Enter an OpenSearch IP address or hostname.")
            if not 1 <= candidate["port"] <= 65535:
                raise ValueError("Port must be between 1 and 65535.")
            if candidate["timeout"] < 1 or candidate["timeout"] > 300:
                raise ValueError("Timeout must be between 1 and 300 seconds.")

            if request.form.get("clear_password") == "on":
                candidate["password"] = ""
            elif request.form.get("password", ""):
                candidate["password"] = request.form["password"]

            action = request.form.get("action", "save")

            if action == "test":
                client = create_client(candidate)
                info = client.info()
                cluster = info.get("cluster_name", "OpenSearch")
                version = info.get("version", {}).get("number", "unknown")
                missing = [
                    name for name in INDEXES
                    if not client.indices.exists(index=name)
                ]
                message = f"Connected to {cluster} (version {version})."
                if missing:
                    message += " Missing indexes: " + ", ".join(missing) + "."
                flash(message, "success" if not missing else "warning")
            else:
                save_config(candidate)
                flash("Settings saved.", "success")
                current = candidate

        except Exception as exc:
            flash(f"Settings error: {friendly_opensearch_error(exc)}", "danger")

        if request.form.get("action") == "test":
            current = candidate

    return render_template(
        "settings.html",
        config=current,
        password_is_set=bool(current.get("password")),
    )


@app.errorhandler(404)
def not_found(_error):
    return render_template("404.html"), 404


if __name__ == "__main__":
    # Keep this bound to loopback. Do not change to 0.0.0.0 unless you add
    # authentication and deliberately intend to expose the management UI.
    app.run(host="127.0.0.1", port=8080, debug=False)
